import React from 'react';
import AnswerQuestion from '@/src/common/answer-question';
import Link from 'next/link';
import Image from 'next/image';
import dashbord from "../../../public/assets/img/service/sv-dashbord.png";
import service_img from "../../../public/assets/img/service/meeting.jpg";

const service_details_content = {
    category_title: "Eğitim İçerikleri",
    categorys: [
        {id: 1, category: "Video Eğitimler", cls: "active"},
        {id: 2, category: "Sınavlar ve Testler", cls: ""},
        {id: 3, category: "Eğitim Dökümanları", cls: ""},
        {id: 4, category: "Sertifikalı Eğitimler", cls: ""},
        {id: 5, category: "İnteraktif Dersler", cls: ""},
    ],
    bg_img: "/assets/img/service/sv-bg.jpg",

    overview_title: "Online Eğitim Platformu",
    overview_des: <>Sendikamızın dijital eğitim platformu, üyelerimizin mesleki ve kişisel
        gelişimlerine katkı sağlayan kapsamlı bir öğrenme deneyimi sunuyor. Video dersler,
        interaktif testler ve zengin döküman arşiviyle desteklenen platformumuz, sendikal
        bilinçten mesleki yetkinliklere kadar geniş bir yelpazede eğitim imkanı sağlıyor.</>,

    overview_list: [
        <>Zengin Video İçerik: <br /> <span>Uzman eğitmenler tarafından hazırlanmış, kategorize edilmiş video eğitim kütüphanesi.</span></>,
        <>Ölçme ve Değerlendirme: <br /> <span>Her eğitim sonrası başarı testleri ve sertifikalandırma sistemi.</span></>,
        <>Kapsamlı Dökümanlar: <span>Eğitim notları, sunumlar ve destekleyici materyallerle zenginleştirilmiş içerik.</span></>,
    ],

    challange_titel: "Sürekli Gelişim",
    challange_des: <>Eğitim platformumuz, üyelerimizin sürekli gelişimini destekleyen
        dinamik bir yapıya sahiptir. Düzenli olarak güncellenen içerikler, interaktif
        öğrenme araçları ve başarı takip sistemiyle, her üyemiz kendi hızında ve
        ihtiyaçları doğrultusunda öğrenme sürecini yönetebilmektedir. İster video
        eğitimlerle, ister dökümanlarla, isterseniz testlerle - öğrenme yolculuğunuzda
        size en uygun yöntemi seçebilirsiniz.</>,
}
const {
    category_title,
    categorys,
    bg_img,
    overview_title,
    overview_des,
    overview_list,
    challange_titel,
    challange_des
}  = service_details_content

const EgitimSistemiArea = () => {

    return (
        <>
            <div className="sv-details-area pt-100 pb-100">
                <div className="container">
                    <div className="row">
                        <div className="col-xl-4 col-lg-4">
                            <div className="sv-details-widget">
                                <div className="sv-details-category mb-30">
                                    <div className="sv-details-category-title">
                                        <h4 className="sv-details-title-sm">{category_title}</h4>
                                    </div>
                                    <div className="sv-details-category-list">
                                        <ul>
                                            {categorys.map((item, i)  =>
                                                <li key={i} className={item.cls}>
                                                    <Link href="#"><span>{item.category}</span><i className="fal fa-angle-right"></i></Link>
                                                </li>
                                            )}
                                        </ul>
                                    </div>
                                </div>

{/*
                                <div className="tp-service__dashboard mb-30" style={{backgroundImage: `url(${bg_img})`}}>
                                    <div className="tp-service__top-content">
                                        <h3 className="tp-service__title-white">Data Analysis <br /> Tools & Methods</h3>
                                        <p>Lorem Ipsum is simply dummy text <br /> of the printing</p>
                                        <Link className="tp-btn-orange tp-btn-hover alt-color-white" href="#">
                                            <span>Work with Us</span>
                                            <b></b>
                                        </Link>
                                    </div>
                                    <div className="tp-service__dashdboard-sm-img">
                                        <Image src={dashbord} className="wow tpfadeRight" data-wow-duration=".9s" data-wow-delay=".3s"
                                               alt="theme-pure" />
                                    </div>
                                </div>

                                <div className="sv-details-social-box mb-30">
                                    <h4 className="sv-details-title-sm">Share it.</h4>
                                    <div className="sv-details-social-link">
                                        <Link href="#"><i className="fab fa-facebook-f"></i></Link>
                                        <Link href="#"><i className="fab fa-twitter"></i></Link>
                                        <Link href="#"><i className="fab fa-instagram"></i></Link>
                                        <Link href="#"><i className="fab fa-youtube"></i></Link>
                                    </div>
                                </div>
*/}

                            </div>
                        </div>

                        <div className="col-xl-8 col-lg-8">
                            <div className="sv-details-wrapper">
                                <div className="sv-details-thumb mb-45">
                                    <Image className="w-100" src={service_img} alt="theme-pure" />
                                </div>
                                <div className="sv-details-title-box mb-55">
                                    <h4 className="sv-details-title">{overview_title}</h4>
                                    <p>{overview_des}</p>
                                </div>
                                <div className="sv-details-text mb-35">
                                    <h4 className="sv-details-text-title pb-10">Her An, Her Yerden Eğitime Erişin!</h4>
                                    <ul>
                                        {overview_list.map((item, i)  =>  <li key={i}> <i className="fal fa-check"></i> <p> {item} </p> </li> )}
                                    </ul>
                                </div>
                                <div className="sv-details-text-2">
                                    <h4 className="sv-details-text-title">{challange_titel}</h4>
                                    <p>{challange_des}</p>
                                </div>
                                <div className="tp-faq-area pt-50">
                                    <div className="container p-0">
                                        <div className="row g-0">
                                            <div className="col-xl-12">
                                                <h4 className="sv-details-title">Sıkça Sorulan Sorular</h4>
                                                <AnswerQuestion style={true} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default EgitimSistemiArea;